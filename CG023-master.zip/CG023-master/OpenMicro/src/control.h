

void control( void);
float clip_ff(float motorin, int number);
float motorfilter( float motorin ,int number);
























