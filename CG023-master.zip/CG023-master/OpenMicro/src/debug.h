

typedef struct debug
{
	int gyroid;
	float vbatt_comp;
	float adcfilt;
	float totaltime;	
	float timefilt;
    float adcreffilt;
} debug_type;




