
int fmc_write( int data1 , int data2);
int readdata( unsigned int data );






