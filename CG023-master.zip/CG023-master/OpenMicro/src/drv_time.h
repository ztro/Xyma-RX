#include <inttypes.h>

void time_init(void);
unsigned long gettime(void);

void delay(uint32_t data);





