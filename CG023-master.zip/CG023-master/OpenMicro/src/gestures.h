
int gestures2( void);
int gesture_sequence( int gesture);

