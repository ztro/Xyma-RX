

void rx_init(void);
void checkrx( void);


struct rxdebug
	{
	unsigned long packettime;
	int failcount;
	int packetpersecond;
	int channelcount[4];
	};



































