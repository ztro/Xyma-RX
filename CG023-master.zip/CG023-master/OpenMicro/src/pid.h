
float pid( int x );
void pid_precalc( void);


